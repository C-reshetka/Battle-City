from menu import Menu
import pygame as pg

if __name__ == '__main__':
    pg.init()
    pg.display.set_caption("Battle City")
    Menu()
